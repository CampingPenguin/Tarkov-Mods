Thanks for downloading!

Place

          Load Order Editor.exe

into your

          user / mods

folder